#ifndef __COG9616_H
#define __COG9616_H

#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"
#include "I2C.h"

void LCD_P16x16Str(unsigned char x,unsigned char y,unsigned char ch[]);
void LCD_Show_Num_8x16(unsigned char x,unsigned char y,int num,int bits);
void LCD_P8x16KStr(unsigned char x,unsigned char y,unsigned char ch[]);
void LCD_P8x16Char(unsigned char x,unsigned char y,unsigned char ch);
void LCD_P8x16Str(unsigned char x,unsigned char y,unsigned char ch[]);
void LCD_P6x8Str(unsigned int x,unsigned int y,unsigned char ch[]);
void LCD_P6x8Char(unsigned int x,unsigned int y,unsigned char ch);
void LCD_Clear(void);
void init_LCD(void);
void I2C_init(void);

#endif
