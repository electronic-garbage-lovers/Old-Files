#ifndef __I2C_H
#define __I2C_H

#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"

void  I2C_init(void);
void  I2C_start(void);
void  I2C_stop(void);
void  I2C_write(UINT8 value);
UINT8 I2C_read(UINT8 ack_mode);


#endif