#ifndef __KEY_CODING_H
#define __KEY_CODING_H

#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"
#include <intrins.h>

void Key_Init(void); 


#endif
