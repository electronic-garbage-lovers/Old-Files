#ifndef __PID_H
#define __PID_H

#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"

UINT16 PID_control(UINT16 target_temp,UINT16 current_temp);

#endif