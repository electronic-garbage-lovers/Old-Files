#ifndef __PWM_H
#define __PWM_H

#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"

void PWM_Init(void);
void Set_PWM(UINT16 pwm_data);

#endif