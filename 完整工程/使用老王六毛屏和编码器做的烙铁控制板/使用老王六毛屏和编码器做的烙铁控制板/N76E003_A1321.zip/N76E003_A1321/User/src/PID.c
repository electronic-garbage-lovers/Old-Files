#include "PID.h"

//PID����
#define Kp 120
#define Kd 0.3

UINT16 PID_control(UINT16 Target_temp,UINT16 Current_temp)
{
	UINT16 pwm_data;
	int    temp_diff;
	temp_diff = Target_temp - Current_temp;

	if(temp_diff<0)
		pwm_data = 0;
	else if((temp_diff>=0)&&(temp_diff<=1))
		pwm_data = Current_temp;
	else if((temp_diff>1)&&(temp_diff<=3))
		pwm_data = Current_temp*3;
	else if((temp_diff>3)&&(temp_diff<=5))
		pwm_data = Current_temp*5;
	else
		pwm_data = 2000;

	if(pwm_data > 2000)
		pwm_data = 2000; 

	return pwm_data;
}
//static int Last_Error=0,Current_Error=0;
//
//UINT16 PID_control(UINT16 Target_temp,UINT16 Current_temp)
//{
//	long   Increment_temp;
//	UINT32 pwm_data;
//
//	Current_Error  = Target_temp - Current_temp;
//	Increment_temp = Kp*Current_Error + Kd*(Current_Error - Last_Error);
//	Last_Error     = Current_Error;
//
//	if(Increment_temp < 0)
//		Increment_temp = 0;
//		 
//	pwm_data = Increment_temp*200;
//	if(pwm_data > 2000)
//		pwm_data = 2000;	 
//
//	return Increment_temp;
//}
