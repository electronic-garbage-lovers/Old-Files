#include "PWM.h"

void PWM_Init(void)
{
	P05_PushPull_Mode;
	PWM2_P05_OUTPUT_ENABLE;
	clr_PWMTYP;
	clr_PWMMOD0;
	clr_PWMMOD1;

	PWM_CLOCK_DIV_8;
	PWMPH = 0x07;
	PWMPL = 0xCF;

	/**********************************************************************
		PWM frequency = Fpwm/((PWMPH,PWMPL) + 1) <Fpwm = Fsys/PWM_CLOCK_DIV> 
									= (16MHz/8)/(0x7CF + 1)
									= 1KHz (1ms)
									
		PWMDT=(PDTCNT+1)/Fpwm	=10/2Mhz=0.005ms
	***********************************************************************/
    PWM2H = 0x00;      
    PWM2L = 0x00;
		
	set_LOAD;
    set_PWMRUN;
}

void Set_PWM(UINT16 pwm_data) //0-2000
{
    PWM2H = pwm_data>>8;             
    PWM2L = pwm_data&0xff;                              
	set_LOAD;
}