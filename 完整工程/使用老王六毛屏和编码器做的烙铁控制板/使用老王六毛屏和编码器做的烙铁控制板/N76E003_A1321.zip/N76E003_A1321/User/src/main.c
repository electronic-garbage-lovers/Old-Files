#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"
#include "COG9616.h"
#include "KEY_Coding.h"
#include "PWM.h"
#include "PID.h"

extern int target_temp;				  //��ת����������Ŀ���¶�
extern bit Key_flag;
UINT16 temp_data_buf[8],current_temp;

unsigned int read_temp(void)
{
	unsigned int ad_data,T;
	unsigned int voltage;
	unsigned char i=0,j;
	
	//�����˴�
	for(i=0;i<8;i++)
	{
		clr_ADCF;
		set_ADCS;
		while(ADCF == 0);
		ad_data=ADCRH;
		ad_data=(ad_data<<4)|ADCRL;
		temp_data_buf[i]=ad_data;
	}

	//��ֵ�˲�
	for(i=0;i<8;i++)
	{
		for(j=0;j<7-i;j++)
		{
			if(temp_data_buf[j]>temp_data_buf[j+1])
			{
				ad_data=temp_data_buf[j+1];
				temp_data_buf[j+1]=temp_data_buf[j];
				temp_data_buf[j]=ad_data;
			}
		}
	}
	//�����¶ȴ���������ֵ���ó���ǰ�¶�
	ad_data =(temp_data_buf[3]+temp_data_buf[4]) / 2;
	voltage =(uint16_t)((uint32_t)ad_data*3300 / 4096);
	T = (uint16_t)((((uint32_t)470*voltage*100/(3300-voltage))-4350)/19);
	return T;
}

void main()
{
	UINT16 pwm_data = 0;
	UINT8  times = 5;

  	I2C_init();	
	init_LCD();
	Key_Init();
	Enable_ADC_AIN3;
	PWM_Init();
	Set_PWM(pwm_data);

	while(1)
	{
		Timer0_Delay1ms(20);

		current_temp = read_temp();
		pwm_data=PID_control(target_temp,current_temp);
		Set_PWM(pwm_data);

		if(Key_flag)
		{
			times = 20;
			Key_flag = 0;
		}
		times--;
		if(times < 5)
			times = 5;
		if(times > 5)
		{
			LCD_P16x16Str(0,4,"�趨");
			LCD_P8x16Str(32,4,":");
			LCD_Show_Num_8x16(40,4,target_temp,3);
			LCD_P8x16Str(64,4,"`C");
		}		
		else
		{
			LCD_P16x16Str(0,4,"��ǰ");
			LCD_P8x16Str(32,4,":");
			LCD_Show_Num_8x16(40,4,current_temp,3);
			LCD_P8x16Str(64,4,"`C");
		}

	}
}

/****************************END OF FILE*************************************/