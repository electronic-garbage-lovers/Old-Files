#include "stm32f10x.h"
#include "epaper.h" 
#include "picture.h"
ErrorStatus HSEStartUpStatus;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);

/************************************************
************************************************/
////////Partial refresh schematic////////////////

/////Y/// ��0,0��          /---/(x,y)
					//                 /---/
					//                /---/  
					//x
					//
					//
						

/////////////////////main//////////////////////////////////////
int main(void)
{
unsigned char fen_L,fen_H,miao_L,miao_H;
	#ifdef DEBUG
	  debug();
	#endif
	RCC_Configuration();
	//GPIO setting
	GPIO_Configuration();
	 
	  //Full screen refresh
		EPD_HW_Init(); //Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_1); //Refresh the picture in full screen
	  EPD_DeepSleep();  //Enter deep sleep
    driver_delay_xms(4000);
//////////////////////Partial refresh digital presentation//////////////////////////////////////
		EPD_SetRAMValue_BaseMap(gImage_logo);  //Partial refresh background color 
	  EPD_Part_Init();//Local refresh initialization (the top left corner of the screen is the origin)
	  EPD_Dis_Part(0,32,gImage_num1,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num2,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num3,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num4,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num5,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num6,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num7,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num8,32,32); //x,y,DATA,Resolution 32*32
		EPD_Dis_Part(0,32,gImage_num9,32,32); //x,y,DATA,Resolution 32*32
	  driver_delay_xms(1000);	
//////////////////////Partial refresh time demo/////////////////////////////////////
		EPD_SetRAMValue_BaseMap(gImage_basemap); //Partial refresh background color  		
		EPD_Part_Init();//Local refresh initialization (the top left corner of the screen is the origin)

		for(fen_H=0;fen_H<6;fen_H++)
		{
		for(fen_L=0;fen_L<10;fen_L++)
		{
		for(miao_H=0;miao_H<6;miao_H++) 	
		{
		for(miao_L=0;miao_L<10;miao_L++)
		{
				EPD_Dis_Part_myself(48,90,Num[miao_L],         //x-A,y-A,DATA-A
														48,122,Num[miao_H],         //x-B,y-B,DATA-B
														48,162,gImage_numdot,       //x-C,y-C,DATA-C
														48,204,Num[fen_L],         //x-D,y-D,DATA-D
														48,236,Num[fen_H],32,64);	 //x-E,y-E,DATA-E,Resolution 32*64
																									
														if((fen_L==0)&&(miao_H==0)&&(miao_L==9))
														goto Clear;
			
		}
		}
		
		}
	}
		
 driver_delay_xms(1000);		
////////////////////////////////////////////////////////////////////////	
			//Clear screen
		Clear:
		EPD_HW_Init(); //Electronic paper initialization
		EPD_WhiteScreen_White(); //Show all white
		EPD_DeepSleep();  //Enter deep sleep
		while(1);		

}
///////////////////////////////////////////////////////////





/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
 
  // Reset RCC clock configuration
  RCC_DeInit();
 
  // Enable external crystal
  RCC_HSEConfig(RCC_HSE_ON);
  
  // Waiting for the external crystal to stabilize
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if(HSEStartUpStatus == SUCCESS)
  {
    // Set the phase-locked loop frequency PLLCLK = 8MHz * 9 = 72 MHz
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
  }
  else {
    // Enable internal crystal
    RCC_HSICmd(ENABLE);
    // Waiting for the internal crystal to stabilize
    while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);

    // Set the phase-locked loop frequency PLLCLK = 8MHz/2 * 16 = 64 MHz 
    RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_16);
  }

    // Enable flash prefetch cache
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

  //Set the code delay, FLASH_Latency_2 is two delay cycles
  FLASH_SetLatency(FLASH_Latency_2);
	
  //Set the system total clock
  RCC_HCLKConfig(RCC_SYSCLK_Div1); 

  //Set the high speed device total clock, RCC_HCLK_Div1 is the system clock divided by 1
  RCC_PCLK2Config(RCC_HCLK_Div1); 

  //Set the low speed device total clock, RCC_HCLK_Div2 is the system clock divided by 2
  RCC_PCLK1Config(RCC_HCLK_Div2);
  
  //Enable phase-locked loop multiplier
  RCC_PLLCmd(ENABLE);
  
  // Waiting for the frequency of the phase-locked loop to multiply after frequency stabilization
  while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
  
  // Select the phase-locked loop clock as the system clock
  RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
  
  // Waiting for setup to complete
  while(RCC_GetSYSCLKSource() != 0x08);
    
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
            RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO,
            ENABLE);

}

/*******************************************************************************
* Function Name  :  GPIO_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);//ʹ��PD��E�˿�ʱ��
	  				     	
	
	 //CS-->PD8   SCK-->PD9  SDO--->PD10 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOD, &GPIO_InitStructure);	  	
	
	
	
	 // D/C--->PE15	   RES-->PE14
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14|GPIO_Pin_15;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);	  				     		
	
	// BUSY--->PE13
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	//Pull down input
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
 	GPIO_Init(GPIOE, &GPIO_InitStructure);				//Initialize GPIO
	
	 //LED
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{ 
  //NVIC_InitTypeDef NVIC_InitStructure;
  ;
}


#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif






